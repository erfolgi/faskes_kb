package com.erfolgi.faskes_kb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
