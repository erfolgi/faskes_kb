import 'layanan.dart';

class Faskes {
 String name;
 String address;
 String img;
 String imgDetail;
 String distance;
 String queue;
 List<Layanan> services;

 Faskes({this.name, this.address, this.img, this.distance, this.queue,
      this.services, this.imgDetail});
}