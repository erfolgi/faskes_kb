class Layanan{
  String name;
  String icon;
  String cost;

  Layanan({this.name, this.icon, this.cost});
}